C old way with large 'lv', this is nevent and needed this for ShakeOut & Hayward sims
C     parameter (mm=65392,mmv=60000,mst=6,lv=1000)
C more general way with small 'lv'
      parameter (mm=65392,mmv=60000,mst=6,lv=10)
      parameter (nq=2000,np=500,nlaymax=500)
