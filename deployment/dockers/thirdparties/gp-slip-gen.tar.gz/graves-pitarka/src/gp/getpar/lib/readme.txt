Directory for the GP command-line parsing library
