#! /usr/bin/env python
"""
Copyright 2010-2019 University Of Southern California

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

 http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
"""
from __future__ import division, print_function

# Import Python modules
import os
import sys
import getopt
from optparse import OptionParser

# Import Broadband modules
import seqnum
import bband_utils
from genslip import Genslip
from install_cfg import InstallCfg

def run_GP_test(options):

    install = InstallCfg()

    if not options.output:
      sim_id = int(seqnum.get_seq_num())
      #sim_id = int(0)
    else:
      sim_id = options.output

    outsrf = "%s.srf" % str(sim_id)

    velmodel = options.velmodel
    srcfile = options.srcfile
    init_slip_file = options.init_slip_file
    slip1_scor = options.slip1_scor

    """
    Create all directories
    """
    indir = os.path.join(install.A_IN_DATA_DIR, str(sim_id))
    tmpdir = os.path.join(install.A_TMP_DATA_DIR, str(sim_id))
    outdir = os.path.join(install.A_OUT_DATA_DIR, str(sim_id))
    logdir = os.path.join(install.A_OUT_LOG_DIR, str(sim_id))

    bband_utils.mkdirs([indir, tmpdir, outdir, logdir],
                        print_cmd=False)

    """
    Copy both velocity model and source file to the working directory
    """
    cmd = "cp %s %s %s/%s/." % (velmodel,
                                srcfile,
                                install.A_IN_DATA_DIR,
                                str(sim_id))

    bband_utils.runprog(cmd, print_cmd=True)


    """
    Test GP rupture generator
    """
    gen = Genslip(velmodel, srcfile,
              outsrf, "SISZBasin",
              init_slip_file,
              slip1_scor,
              sim_id=sim_id)
    gen.run()

if __name__ == '__main__':

    ''' Read input parameters '''
    parser = OptionParser(usage='usage: %prog [options] arguments (-h for help)')
    parser.add_option('-s', '--src',
                            dest='srcfile',
                            help='Source setup file')

    parser.add_option('-v', '--vm',
                            dest='velmodel',
                            help='Velocity model file')

    parser.add_option('-i', '--slip',
                            dest='init_slip_file',
                            help='Initial slip file assumption')

    parser.add_option('-a', '--asperity',
                            type="float",
                            dest='slip1_scor',
                            help='% of Asperity preservation [0.0, 1.0]')

    parser.add_option('-o', '--output',
                            dest='output',
                            help='output directory')

    (options, args) = parser.parse_args()

    if not options.srcfile:
        parser.error('Source file not given')

    if not options.velmodel:
        parser.error('Velocity model not given')

    if not options.init_slip_file:
        options.init_slip_file = ""

    if not options.slip1_scor:
        options.slip1_scor = 0.0

    ''' start the Graves-Pitarka rupture generator '''
    run_GP_test(options)
