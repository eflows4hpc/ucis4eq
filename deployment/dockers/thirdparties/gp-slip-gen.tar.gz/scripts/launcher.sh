#!/bin/bash

source /root/.bashrc

python /root/scripts/GP_GenSlip.py "$@"

