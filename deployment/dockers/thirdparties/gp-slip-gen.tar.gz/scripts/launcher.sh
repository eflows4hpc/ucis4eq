#!/bin/bash

source /opt/.bashrc

python /opt/scripts/GP_GenSlip.py "$@"

