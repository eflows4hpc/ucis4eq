#!/bin/bash

# Exit immediately if a command exits with a non-zero status
set -e

# Prepare environment
source /root/.bashrc

# Load specific environemnt variables
source /root/env.source

# Install Salvus
pip install Salvus/python_packages/salvus-*.whl

# Add launch script
cp -R Salvus/scripts /root/

# Add services
cp -R Salvus/services /root/

# Add Salvus compute
cp Salvus/bin/* /root/miniconda3/envs/salvus/bin/
cp Salvus/lib/* /lib/x86_64-linux-gnu/

# Prepare .ssh/config
cp Salvus/config /root/.ssh/config

# Configure local site
mkdir -p /root/.config/SalvusFlow/1.0/
cp Salvus/salvus-flow-config.toml /root/.config/SalvusFlow/1.0/
sed -i "s/MN4USERNAME/$MN4_USERNAME/g" /root/.config/SalvusFlow/1.0/salvus-flow-config.toml
sed -i "s/MN4QOS/$MN4_QOS/g" /root/.config/SalvusFlow/1.0/salvus-flow-config.toml
sed -i "s|MN4SALVUSPATH|$MN4_SALVUS_PATH|g" /root/.config/SalvusFlow/1.0/salvus-flow-config.toml
sed -i "s|MN4SALVUSRUNPATH|$MN4_SALVUS_RUN_PATH|g" /root/.config/SalvusFlow/1.0/salvus-flow-config.toml
sed -i "s|MN4SALVUSTMPPATH|$MN4_SALVUS_TMP_PATH|g" /root/.config/SalvusFlow/1.0/salvus-flow-config.toml

# Prepare licenses
cp Salvus/salvus-licenses.toml /root/.salvus-licenses.toml
sed -i "s/USERNAME/$SALVUS_USERNAME/g" /root/.salvus-licenses.toml
sed -i "s/PASSWORD/$SALVUS_PASSWORD/g" /root/.salvus-licenses.toml

# Initialize local (Demo) site
salvus-flow init-site demo

# Initialize MN4 site
salvus-flow init-site mn4

# Restore blank Salvus license and sites config
cp Salvus/salvus-licenses.toml /root/.salvus-licenses.toml
cp Salvus/salvus-flow-config.toml /root/.config/SalvusFlow/1.0/

# Remove copied installation file
rm -fr Salvus
rm -fr /root/env.source
