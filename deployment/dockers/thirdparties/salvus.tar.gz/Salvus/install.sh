#!/bin/bash

# Exit immediately if a command exits with a non-zero status
set -e

# Prepare environment
source /root/.bashrc

# Install Salvus
pip install Salvus/python_packages/salvus-*.whl

# Prepare licenses
cp Salvus/salvus-licenses.toml /root/.salvus-licenses.toml

# Add launch script
mv Salvus/scripts /root/

# Add services
mv Salvus/services /root/

# Add Salvus compute
cp Salvus/bin/* /root/miniconda3/envs/salvus/bin/
cp Salvus/lib/* /lib/x86_64-linux-gnu/

# Configure local site
mkdir -p /root/.config/SalvusFlow/1.0/
cp Salvus/salvus-flow-config.toml /root/.config/SalvusFlow/1.0/
sed -i "s/USERNAME/$SALVUS_USERNAME/g" /root/.salvus-licenses.toml
sed -i "s/PASSWORD/$SALVUS_PASSWORD/g" /root/.salvus-licenses.toml

# Initialize local (Demo) site
salvus-flow init-site demo
# Initialize MN4 site
#salvus-flow init-site mn4

# Restore blank Salvus license
cp Salvus/salvus-licenses.toml /root/.salvus-licenses.toml

# Remove copied installation file
rm -fr Salvus
