#!/bin/bash

# Prepare environment
source /root/.bashrc

# Set the license username && password
sed -i "s/USERNAME/$SALVUS_USERNAME/g" /root/.salvus-licenses.toml
sed -i "s/PASSWORD/$SALVUS_PASSWORD/g" /root/.salvus-licenses.toml 

# Launch Salvus services
python3 /root/services/salvusService.py
