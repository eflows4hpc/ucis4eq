#!/bin/bash

# Prepare environment
source /root/.bashrc

# Load specific environemnt variables
source /root/env.source

# Set the license username && password
sed -i "s/USERNAME/$SALVUS_USERNAME/g" /root/.salvus-licenses.toml
sed -i "s/PASSWORD/$SALVUS_PASSWORD/g" /root/.salvus-licenses.toml

sed -i "s/MN4USERNAME/$MN4_USERNAME/g" /root/.config/SalvusFlow/1.0/salvus-flow-config.toml
sed -i "s/MN4QOS/$MN4_QOS/g" /root/.config/SalvusFlow/1.0/salvus-flow-config.toml

# Launch Salvus services
python3 /root/services/salvusService.py
